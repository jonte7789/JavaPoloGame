# Seng201 Project Submission 

How to run the game:

1. After downloading the ZIP archive, unzip the file.
2. After unzipping the file, navigate to Eclipse or IDE of choice, in any directory (not dependent) create a new java project, feel free to name it anything. File -> new -> Java Project  
3. After creating this java project, right click on the new java project folder (on the IDE), select import, navigate to file systems, locate where you downloaded the original ZIP folder (now unzipped), select this folder, navigate to the folder labeled seng201pologame-main, open this and select the folder 'Main' and click open/select files. Select all files to import within this folder, and click finish.
4. Now that all files have been imported, navigate to the teammanager file, and select run. From here the game will launch the setupscreen, and you are now playing the game.

